const { login } = require("./auth");

const result = login("admin", "admin123");
console.log(result);
